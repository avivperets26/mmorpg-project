// Assets/Scripts/Inventory/PlayerInventory.cs
using System;
using System.Collections.Generic;
using UnityEngine;
using Game.Items;

/// <summary>
/// Player-facing API for storing items in a grid and notifying UI.
/// </summary>
public class PlayerInventory : MonoBehaviour
{
    [Header("Grid Size")]
    public int gridWidth = 6;
    public int gridHeight = 6;

    public InventoryData Data { get; private set; }

    // Top-left placed instances
    private readonly List<InventoryItem> _items = new();
    public IReadOnlyList<InventoryItem> Items => _items;

    /// <summary>
    /// Raised after any add/remove so UI can refresh.
    /// </summary>
    public event Action Changed;

    private void Awake()
    {
        Data = new InventoryData(gridWidth, gridHeight);
    }

    /// <summary>
    /// Tries to place the item scanning left-to-right, top-to-bottom.
    /// </summary>
    public bool TryAdd(ItemDefinition def)
    {
        if (def == null)
        {
            Debug.LogWarning("[Inventory] TryAdd called with null ItemDefinition");
            return false;
        }

        // 🔹 1) If this is a potion, try to stack first
        if (def is PotionItemDefinition potionDef)
        {
            // Look for an existing stack of this potion
            for (int i = 0; i < _items.Count; i++)
            {
                var it = _items[i];
                if (it.def == def)
                {
                    // Safety clamp
                    if (it.quantity < potionDef.maxStack)
                    {
                        it.quantity = Mathf.Min(it.quantity + 1, potionDef.maxStack);
                        // Debug.Log($"[Inventory] Stacked '{def.displayName}' -> qty={it.quantity}");
                        Changed?.Invoke();
                        return true;
                    }
                }
            }
            // If no stack found or all full, fall through to normal placement below
        }

        // 🔹 2) Normal grid placement (weapons, armor, or new stack)
        for (int pass = 0; pass < 2; pass++)
        {
            bool rotated = pass == 1;

            for (int y = 0; y < Data.height; y++)
            {
                for (int x = 0; x < Data.width; x++)
                {
                    var candidate = new InventoryItem
                    {
                        def = def,
                        x = x,
                        y = y,
                        rotated = rotated,
                        quantity = 1
                    };

                    if (Data.Place(candidate))
                    {
                        _items.Add(candidate);
                        // Debug.Log($"[Inventory] Added '{def.displayName}' at {x},{y}, rotated={rotated}. Count={_items.Count}");
                        Changed?.Invoke();
                        return true;
                    }

                }
            }
        }

        Debug.LogWarning("[Inventory] No free space for item");
        return false;
    }

    /// <summary>
    /// Removes the specific placed instance.
    /// </summary>
    public void Remove(InventoryItem it)
    {
        if (it == null)
        {
            Debug.LogWarning("[Inventory] Remove called with NULL instance");
            return;
        }

        int before = _items.Count;
        bool had = _items.Contains(it);

        // Clear any cells referencing this specific instance
        Data.Remove(it);

        // Remove instance from list
        bool removed = _items.Remove(it);
        int after = _items.Count;

        Debug.Log($"[Inventory] RemoveInstance → def='{it.def?.displayName ?? "NULL"}', " +
                  $"hadBefore={had}, removedNow={removed}, count {before}→{after}, " +
                  $"coords=({it.x},{it.y}), rotated={it.rotated}");

        Changed?.Invoke();
    }


    /// <summary>
    /// Convenience: removes the first placed instance of a given definition.
    /// </summary>
    public bool RemoveFirst(ItemDefinition def)
    {
        var idx = _items.FindIndex(i => i.def == def);
        if (idx < 0) return false;

        var it = _items[idx];
        Data.Remove(it);
        _items.RemoveAt(idx);
        Changed?.Invoke();
        return true;
    }

    /// <summary>
    /// Clears everything (useful for testing).
    /// </summary>
    public void ClearAll()
    {
        foreach (var it in _items)
            Data.Remove(it);
        _items.Clear();
        Changed?.Invoke();
    }

    /// <summary>
    /// Consumes one unit from the given stack. If quantity reaches 0, removes the item.
    /// Returns true if something was consumed.
    /// </summary>
    public bool ConsumeOne(InventoryItem it)
    {
        if (it == null || it.def == null)
        {
            Debug.LogWarning("[Inventory] ConsumeOne called with null item/def");
            return false;
        }

        if (it.quantity <= 0)
        {
            Debug.LogWarning("[Inventory] ConsumeOne on item with non-positive quantity");
            return false;
        }

        it.quantity--;

        if (it.quantity <= 0)
        {
            // Clear from grid + list
            Data.Remove(it);
            _items.Remove(it);
        }

        Changed?.Invoke();
        return true;
    }

    /// <summary>
    /// Convenience: consumes one unit from the first stack with the given definition.
    /// Returns true if something was consumed.
    /// </summary>
    public bool ConsumeOne(ItemDefinition def)
    {
        if (def == null)
        {
            Debug.LogWarning("[Inventory] ConsumeOne(def) called with null def");
            return false;
        }

        for (int i = 0; i < _items.Count; i++)
        {
            var it = _items[i];
            if (it == null || it.def != def) continue;

            // Delegate to the existing stack-based ConsumeOne
            return ConsumeOne(it);
        }

        Debug.Log($"[Inventory] ConsumeOne(def) could not find instance of '{def.displayName}'.");
        return false;
    }

}
